import { AppRouter } from './Router';

/**
 * Main application component
 */
export function App() {
  return <AppRouter />;
}
